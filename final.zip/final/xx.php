<html>
<body>
 "Successfully Registered!";
 <br>
<a href='userlogin.php'>Click here to Login</a>;
</body>
</html>