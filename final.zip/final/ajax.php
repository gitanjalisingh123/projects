<?php
// Array with names
$a[] = "PANVEL";
$a[] = "belapur";
$a[] = "gtb";
$a[] = "khandeshwar";
$a[] = "mansarovar";
$a[] = "mulund";
$a[] = "bhandup";
$a[] = "nerul";
$a[] = "vashi";
$a[] = "juinagar";
$a[] = "ghansoli";
$a[] = "koparkhairane";
$a[] = "airoli";
$a[] = "bandara";
$a[] = "kasara";
$a[] = "seawoods";
$a[] = "kharghar";
$a[] = "naupada";
$a[] = "bhiwandi";
$a[] = "csmt";
$a[] = "thane";
$a[] = "hyderabad";
$a[] = "sion";
$a[] = "kalyan";
$a[] = "dombivili";
$a[] = "dockyard";
$a[] = "rabale";
$a[] = "elphiston";
$a[] = "churchgate";
$a[] = "ghatkopar";

// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from "" 
if ($q !== "") {
    $q = strtolower($q);
    $len=strlen($q);
    foreach($a as $name) {
        if (stristr($q, substr($name, 0, $len))) {
            if ($hint === "") {
                $hint = $name;
            } else {
                $hint .= ", $name";
            }
        }
    }
}

// Output "no suggestion" if no hint was found or output correct values 
echo $hint === "" ? "no suggestion" : $hint;
?>