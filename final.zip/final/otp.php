<?php
session_start();
if(isset($_POST['save']))
{
$rno=$_SESSION['otp'];
$urno=$_POST['otpvalue'];
if(!strcmp($rno,$urno))
{
$name=$_SESSION['name'];
$email=$_SESSION['email'];
$phone=$_SESSION['phone'];
//For admin if he want to know who is register
$to=$_POST['email'];
$subject = "Thank you!";
$txt = "Some one show your demo Email id: ".$email." Mobile number : ".$phone."";
$headers = "From: ssdoller@gmail.com" . "\r\n" .
"CC: zagadepvit16e@student.mes.ac.in";
mail($to,$subject,$txt,$headers);
echo "<p>Thank you for show our Demo.</p>";
//For admin if he want to know who is register
}
else{
echo "<p>Invalid OTP</p>";
}
}
//resend OTP
if(isset($_POST['resend']))
{
$message="<p class='w3-text-green'>Sucessfully send OTP to your mail.</p>";
$rno=$_SESSION['otp'];
$to=$_SESSION['email'];
$subject = "OTP";
$txt = "OTP: ".$rno."";
$headers = "From: zagadepvit16e@student.mes.ac.in" . "\r\n" .
"CC:zagadepvit16e@student.mes.ac.in";

					
require("PHPMailer-master/src/PHPMailer.php");
require("PHPMailer-master/src/SMTP.php");
$mail = new PHPMailer\PHPMailer\PHPMailer();
		$mail->IsSMTP(); 		$mail->SMTPDebug  = 0;                     
		$mail->SMTPAuth   = true;                  
		$mail->SMTPSecure = "ssl";                 
		$mail->Host       = "smtp.gmail.com";      
		$mail->Port       = 465;             
		$mail->AddAddress($email);

mail($to,$subject,$txt,$headers);
$message="<p class='w3-text-green w3-center'><b>Sucessfully resend OTP to your mail.</b></p>";
}
?>
<!DOCTYPE html>
<html>
<header>
<title>One Time Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://studentstutorial.com/div/d.css">
<style>
a{
text-decoration:none;
}

.FORM{

	position: center; 
	border-color: black;


}
fieldset{

	padding: 50px;
	margin-right: 300px;
	margin-top: 100px;
	margin-left:100px; 
}
input {
	position: center;
	margin-left: 60px;
} 
button{

	position: center;
}
#txt{
	text-align: center;
	font-color:red;
	font-size: 30px;

}
</style>
<header>
<body>
<br>
<div class="w3-row">
<div class="w3-half w3-card-2 w3-round">
<div class="w3-container w3-center w3-green">
<h2 text-align="center">One Time Password</h2>
</div>
<br>
<div class="FORM">
	<fieldset>
<form class="w3-container" method="post" action="userlogin.php">
<br>
<br>
<p><input class="w3-input w3-border w3-round" type="password" style="width:50%;height:40px" placeholder="OTP" name="otpvalue"></p>
<p class="w3-center"><button class="w3-btn w3-green w3-round" style="width:50%;height:40px;background-color: red" name="save">Submit</button></p>
<p class="w3-center"><button class="w3-btn w3-green w3-round" style="width:50%;height:40px;background-color: blue" name="resend">Resend</button></p>
</form></fieldset></div>
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<br>
</div>
<div class="w3-half">
</div>
</div>
</body>
</html> 