<?php
session_start();
include_once("db_connect.php");
$email= $_POST['email'];
isset($_SESSION["email"]);
require_once 'sendMailD.php';

$mailF = new sendMailD();
    try
    {
    $userOtpRCode = "#column#";
    $userEmail = $email; //email id of receiver
              $message= "
                           Hello ,
                           <br /><br />
                           $email is here to apply for u
                           <br /><br />
                           your new password is=  $userOtpRCode
                           <br /><br />
                           
                           <br /><br />
                           Thank you";
                        $subject = "PASSWORD RESET";
                
                        $retv = $mailF->sendMail($userEmail,$message,$subject);

                        if($retv == "OK"){
                         echo "your new password has been sent on your email id";
                        }          
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }


?>