<html>
<style>
form{

  margin: 120px 120px 120px;

}
body {
  font-family: Arial, Helvetica, sans-serif;
  color: #0db3e5;
  background-image: url("backsign.jpg");
  background-size: cover;
  background-attachment: fixed;

}

* {box-sizing: border-box}
/* Full-width input fields */
input[type=text], input[type=pswd] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: transparent;
    color: white;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=pswd]:focus {
    background-color: #ddd;
    outline: none;
    display: block;
    color: black;
}
input[type=text], input[type=cpswd] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: transparent;
    color: white;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=cpswd]:focus {
    background-color: #ddd;
    outline: none;
    display: block;
    color: black;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}

/* Extra styles for the cancel button */


/* Float cancel and signup buttons and add an equal width */
 .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
    padding: 16px;
}


/* Style the horizontal ruler */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
    position: absolute;
    right: 35px;
    top: 15px;
    font-size: 40px;
    font-weight: bold;
    color: #f1f1f1;
}

.close:hover,
.close:focus {
    color: #f44336;
    cursor: pointer;
}

/* Clear floats */


/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
   .signupbtn {
       width: 100%;
    }
}
#abc{
  background-position: center;
  color: #29dbcf;
  text-align: center;
  display: block;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 50px;
}
</style>
<body>
<?php
include_once("db_connect.php");
session_start();
if(isset($_SESSION['id'])) {
  header("Location: index.php");
}

$error = false;

if (isset($_POST['injection'])) {
  
  $fname = mysqli_real_escape_string($conn, $_POST['fname']);
  $mname = mysqli_real_escape_string($conn, $_POST['mname']);
  $lname = mysqli_real_escape_string($conn, $_POST['lname']);
  $address = mysqli_real_escape_string($conn, $_POST['address']);
  $contact =mysqli_real_escape_string($conn, $_POST['contact']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $pswd = mysqli_real_escape_string($conn, $_POST['pswd']);
  $cpswd = mysqli_real_escape_string($conn, $_POST['cpswd']); 
 
  
  
  if (!preg_match("/^[a-zA-Z ]+$/",$fname)) {
   $error = true;
    $fname_error = "Name must contain only alphabets and space";
  } 
   if (!preg_match("/^[a-zA-Z ]+$/",$mname)) {
    $error = true;
    $mname_error = "Name must contain only alphabets and space";
  }
   if (!preg_match("/^[a-zA-Z ]+$/",$lname)) {
    $error = true;
    $lname_error = "Name must contain only alphabets and space";
  }
   if (!preg_match("/^[a-zA-Z ]+$/",$address)) {
    $error = true;
    $address_error = "address must contain only alphabets and space";
  }
   if(strlen($contact) > 11) {
    $error = true;
    $contact_error = "contact must be minimum of 11 characters";
  }
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
    $error = true;
    $email_error = "Please Enter Valid Email ID";
  }
  if(strlen($pswd) < 6) {
    $error = true;
    $pswd_error = "Password must be minimum of 6 characters";
  }
  if($pswd != $cpswd) {
    $error = true;
    $cpswd_error = "Password and Confirm Password doesn't match";
  }
    $sql= "INSERT INTO admin(fname, mname, lname, address, contact, email, pswd, cpswd) VALUES(?,?,?,?,?,?,?,?);";
    $stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
      echo "sql error";
    }else{
      mysqli_stmt_bind_param($stmt,"ssssssss", $fname, $mname, $lname, $address, $contact, $email, $pswd, $cpswd);
      mysqli_stmt_execute($stmt);
    }
}

?>
<div class="container">
      <h1>Sign Up</h1>
      <div class="row">
      <p>Please fill in this form to create an account.</p>

    <div class="col-md-8 col-md-offset-8 well">
      <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="injection">

        <fieldset>
          <legend>Sign Up</legend>
          <div class="form-group">
            <label for="fname">FName</label>
            <input type="text" name="fname" placeholder="Enter fname Name" required value="<?php if($error) echo $fname; ?>" class="form-control" />
          </div> 
           <div class="form-group">
            <label for="name">MName</label>
            <input type="text" name="mname" placeholder="Enter mname Name" required value="<?php if($error) echo $mname; ?>" class="form-control" />
          </div> 
           <div class="form-group">
            <label for="name">LName</label>
            <input type="text" name="lname" placeholder="Enter lname Name" required value="<?php if($error) echo $lname; ?>" class="form-control" />
            
          </div>  
         <div class="form-group">
            <label for="name">Address</label>
            <input type="text" name="address" placeholder="Enter your address" required value="<?php if($error) echo $address; ?>" class="form-control" />
            
          </div>  
           <div class="form-group">
            <label for="name">Contact</label>
            <input type="text" name="contact" placeholder="Enter your phone no." required value="<?php if($error) echo $contact; ?>" class="form-control" />
           
          </div>        
          <div class="form-group">
            <label for="name">Email</label>
            <input type="text" name="email" placeholder="Email" required value="<?php if($error) echo $email; ?>" class="form-control" />
          </div>
          <div class="form-group">
            <label for="name">Password</label>
            <input type="pswd" name="pswd" placeholder="Password" required class="form-control" />
          </div>
          <div class="form-group">
            <label for="name">Confirm Password</label>
            <input type="cpswd" name="cpswd" placeholder="Confirm Password" required class="form-control" />
          </div>
          <div class="form-group">
            <input type="submit" name="injection" value="Sign Up" class="signupbtn" />
          </div>
        </fieldset>
      </form>
     </div>
  </div>
  <div class="row">
    <div class="col-md-8 col-md-offset-8 text-center">  
    Already Registered? <a href="userlogin.php">Login Here</a>
    </div>
  </div>  
</div>
</body>
</html>