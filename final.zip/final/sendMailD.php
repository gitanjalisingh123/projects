<?php

class sendMailD
{	

	private $conn;
	
	
	
	function sendMail($email,$message,$subject)
	{						
		require("PHPMailer-master/PHPMailer.php");
  require("PHPMailer-master/src/SMTP.php");

    $mail = new PHPMailer\PHPMailer\PHPMailer();
		$mail->IsSMTP(); 
		$mail->SMTPDebug  = 0;                     
		$mail->SMTPAuth   = true;                  
		$mail->SMTPSecure = "ssl";                 
		$mail->Host       = "smtp.gmail.com";      
		$mail->Port       = 465;             
		$mail->AddAddress($email);
		  
		$mail->Username='gitanjali1502@gmail.com';  
		$mail->Password='#anjii99#';   
		  
		$mail->SetFrom('gitanjali1502@gmail.com','crime mapping');
		$mail->Subject    = $subject;
		$mail->MsgHTML($message);
		if(!$mail->send()) {
			  return "FAIL";
		} else {
  				return "OK";
		}
		

	}	
}

?>