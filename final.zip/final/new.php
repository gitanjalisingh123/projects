<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
	body{
		background-image: url("new3.jpg");
		background-attachment: fixed;
		background-size: cover;
		background-repeat: no-repeat;
	}
		
		ul li {

		}
		a{
			text-decoration:none;

		}
		.btn2{
			background-color: yellow;
			padding-right: 15px;
			margin-top: 40px;
			border: 2px solid;
		}
		.btn1{

			background-color: red;
			margin-top: 35px;
			border: 2px solid;
		}
		ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: white;
    text-align: center;
    padding: 10px 22px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color: #0db3e5;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}
	</style>
</head>
<body>

	 <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="350">
  <ul class="topnav">
        <li><a href="pp.php"><strong>ABOUT US</a></li>
        <li><a href="contus.php"><strong>CONTACT US</a></li>
        <LI><a href="sample.php"><strong>HOME</a></LI>
    </ul>
<div class="button"  style="font-size: 50px;
			list-style: none;
			line-height: 50px;
			font-family:  Arial, Helvetica, sans-serif;;
			float: left;
			padding: 50px;
			text-align: center;	">
	<ul>
	<li><a style="text-decoration:none;list-style: none; " href="loginadmin.php" class="btn1">Admin</a></li>
<br>
	<li><a href="userlogin.php" class="btn2">User</a></li>
</div>

</div>
</body>
</html>