<?php
session_start();
include_once 'db_connect.php';
if(isset($_POST['submit']))
{
$user_id = $_POST['email'];
$result = mysqli_query($conn,"SELECT * FROM admin where email='" . $_POST['email'] . "'");
$row = mysqli_fetch_assoc($result);
$fetch_user_id=$row['id'];
$email_id=$row['email'];
$password=$row['pswd'];
if($user_id==$fetch_user_id) {
$to = $email_id;
$subject = "Password";
$txt = "Your password is : $pswd.";
$headers = "From: ssdoller@gmail.com" . "\r\n" .
"CC: zagadepvit16e@student.mes.ac.in";
mail($to,$subject,$txt,$headers);
}
else{
echo 'invalid userid';
}
}
?>
<!DOCTYPE HTML>
<html>
<head>
<style type="text/css">
input{
border:1px solid olive;
border-radius:5px;
}
h1{
color:darkgreen;
font-size:22px;
text-align:center;
}
</style>
</head>
<body>
<h1>Forgot Password<h1>
<form action='' method='post'>
<table cellspacing='5' align='center'>
<tr><td>user id:</td><td><input type='text' name='user_id'/></td></tr>
<tr><td></td><td><input type='submit' name='submit' value='Submit'/></td></tr>
</table>
</form>
</body>
</html>