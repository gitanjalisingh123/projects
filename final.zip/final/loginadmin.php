<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
    background-image: url("okay.png");
    background-size: cover;
    background-attachment: fixed;
    background-repeat: no-repeat;
    color: black;
    display: block;

   }

form{
    
    margin:200px 400px 600px;
    box-sizing: content-box;
    padding: 15px 5px 0px;
    background-color: white;
	opacity: 0.6;     
      }

  ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color: #111;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}




/* Full-width input fields */
input[type=text], input[type=password] {
    width: 30%;
	padding: 12px 14px;
    margin: 8px 0;
    display:block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    background: transparent;
    color: white;
}

/* Set a style for all buttons */
#Login{
    background-color: #4e0859;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
    height: 50%;
    float:left; 
}

#signup{
    background-color:#912a32;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
    float: right;
}

button:hover {
    opacity: 0.8;
}

/* Extra styles for the cancel button */


/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}



.container {
    padding: 0px;
    border-width: 5px; 
    background: transparent;
 	padding-left: 5px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
</head>
<body>
<?php
session_start();
include_once("db_connect.php");
if(isset($_SESSION['user_id'])!="") {
	header("Location: home.php");
}
if (isset($_POST['loginadmin'])) {
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$pswd = mysqli_real_escape_string($conn, $_POST['pswd']);
	$result = mysqli_query($conn, "SELECT * FROM uadmin WHERE email = '" . $email. "' and pswd = '" . $pswd. "'");
	 $email1 ="";
    $pswd1="";
    while ($row = $result->fetch_assoc())
     {
        $email1 = $row['email'];
        $pswd1 = $row['pswd'];
    }
    if ($email1==$email && $pswd==$pswd1)
     {
       echo "<script>window.location.href='alogged.php'</script>";
    }
    else
    {
        echo "<script>window.alert(' Invalid Email or password ')</script>";
    }
}
?><div>
  <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="350">
 <ul class="topnav">
        <li><a href="pp.php"><strong>ABOUT US</a></li>
        <li><a href="contus.php"><strong>CONTACT US</a></li>
        <LI><a href="sample.php"><strong>HOME</a></LI>
    </ul>
</div>
<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginadmin">
<div class="container">	
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			
				
										
					<div class="form-group">
						<label for="name">Email</label>
						<input type="text" name="email" placeholder="Your Email" required class="form-control" />
					</div>	<br>
					<div class="form-group">
						<label for="name">Password</label>
						<input type="password" name="pswd" placeholder="Your Password" required class="form-control" />
					</div>	<br>
					<div class="form-group">
						<input type="submit" name="loginadmin" value="Login" class="btn btn-primary" />
					</div>
				
			</form>
			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
		</div>
	</div><br>
	<div class="row">
		<div class="col-md-4 col-md-offset-4 text-center">	
		New User? <a href="adminsignup.php">Sign Up Here</a>
		</div>
	</div>	
</div>
 <footer>
    	<div class="copyright-and-privicy-links hidden-xs hidden-sm">
      <b><p style="color: blue; text-align: center;">&copy;2018 CrimeReports</p></b>
    </footer>
  </main> 