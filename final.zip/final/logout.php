<?php
ob_start();
session_start();
if(isset($_SESSION['id'])) {
	session_destroy();
	unset($_SESSION['id']);
	unset($_SESSION['fname']);
	header("Location: loginadmin.php");
} else {
	header("Location: loginadmin.php");
}
?>