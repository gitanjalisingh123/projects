<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
    background-image: url("sbp3.jpg");
    background-attachment: fixed;
    background-size:cover;
    color: white;
}

ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color: #111;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}

form{
   
    margin:100px 350px 400px;
    background: transparent;
    padding: 0px;
     
    }
/* Full-width input fields */
input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display:block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    background: transparent;
    color: white;
}

/* Set a style for all buttons */
.login{
    background-color: #4e0859;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
    float:left; 
}

#signup{
    background-color:#912a32;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
    float: right;
}

button:hover {
    opacity: 0.8;
}

/* Extra styles for the cancel button */


/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}

img.avatar {
    width: 25%;
    height: 30%;
    border-radius: 50%;
    position: relative;
    margin-left: 0px;
}

.container {
    padding: 16px;
    background: transparent;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}
a{

    position: center;
    text-decoration :none;
    color: white;

}
/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}

input[type=submit]{

    font-family: Arial, Helvetica, sans-serif;
    background-color: #995b4c;
    color: white;
    font-size: 20px;
}
</style>
</head>
<body>
      <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="350">
    <ul class="topnav">
        <li><a href="pp.php">ABOUT US</a></li>
        <li><a href="contus.php">CONTACT US</a></li>
        <LI><a href="sample.php">HOME</a></LI>
    </ul>


<div id="id01" class="modal">
     <form class="modal-content animate" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="userlogin">
    <div class="imgcontainer">
      <img src="icon.jpg" alt="Avatar" class="avatar">
    </div>

    <div class="container"> 
    <div class="row">
        <div class="col-md-6 col-md-offset-8 well">
            
            
                                        
                    <div class="form-group">
                        <label for="name">Email</label>
                        <input type="text" name="email" placeholder="Your Email" required class="form-control" />
                    </div>  
                    <div class="form-group">
                        <label for="name">Password</label>
                        <input type="password" name="pswd" placeholder="Your Password" required class="form-control" />
                    </div>  <br>
                    <div class="form-group">
                        <input type="submit" name="userlogin" value="Login" class="btn btn-primary" />
                    </div>
                
               
            </form>
            <span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
        </div><br>
        <br>
    </div>
    <div class="row">
        <div class="col-md-4 col-md-offset-4 text-center">  
        New User? <a href="usersign.php">Sign Up Here</a>
        </div>
    </div>  
</div>
 <footer>
        <div class="copyright-and-privicy-links hidden-xs hidden-sm">
      <b><p style="color: blue; text-align: center;">&copy;2018 CrimeReports</p></b>
    </footer>
  </main> 
<script>
// Get the modal
var modal = document.getElementById('id01');
var modal = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>
</html>
<?php

include_once("db_connect.php");

if (isset($_POST['userlogin'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pswd = mysqli_real_escape_string($conn, $_POST['pswd']);
    $result = mysqli_query($conn, "SELECT * FROM admin WHERE email = '" . $email. "' and pswd = '" . $pswd. "'");
    $email1 ="";
    $pass1="";
    while ($row = $result->fetch_assoc())
     {
        $email1 = $row['email'];
        $pass1 = $row['pswd'];
    }
    if ($email1==$email && $pswd==$pass1)
     {
       echo "<script>window.location.href='logged.php'</script>";
    }
    else
    {
        echo "<script>window.alert('Invalid Email or password ')</script>";
    }

    
    /*if ($row = mysqli_fetch_array($result)) {
        $_SESSION['id'] = $row['id'];
        $_SESSION['fname'] = $row['fname'];
        header("Location: index.php");
    } else {
        $error_message = "Incorrect Email or Password!!!";
    }*/
}
?>