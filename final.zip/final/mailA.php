<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;
    background-color: lightblue; }
form { width : 20% border: 20% solid #f1f1f1; }


input[type=text], input[type=password] {
    width: 20%;
    padding: 12px 20px;
    margin: 8px 0;
    display: center;
    
    box-sizing: border-box;
}
input
{ align="left|right|middle|top|bottom";
}

button {
    align-items: center;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 20%;

}

button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: black ;
}



.button { margin: 0 auto; display: inline-block; width: 30%; border-radius: 10px; border: none; padding: 10px 20px; color: aliceblue;}


.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    
}
</style>
</head>
<body>

<h2 style="text-align:center;">OTP Verification</h2>

<form action = "xx.php">
 

    
    <input type="password" placeholder="Enter your OTP" name="psw" style="text-align:center;" required>
    <br>
        
    <button type="submit" style="display: flex; justify-content: center;">Submit</button>
    
  </div>

 
  </div>
</form>

</body>
</html>

<?php
session_start();
$email= 'singhgi16e@student.mes.ac.in';
isset($_SESSION["email"]);
require_once 'sendMailD.php';
$mailF = new sendMailD();
    try
    {
    $userOtpRCode = "2210";
    $userEmail = $email; //email id of recevr
              $message= "
                           Hello ,
                           <br /><br />
                           $email is here to apply for u
                           <br /><br />
                           Your one time verification code is  $userOtpRCode
                           <br /><br />
                           
                           <br /><br />
                           Thank you";
                        $subject = "LOOK FOR CRIME";
                
                        $retv = $mailF->sendMail($userEmail,$message,$subject);

                        if($retv == "OK"){
                         echo "check your mail for otp";

                          header('sample.php');
                        }          
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }


?>