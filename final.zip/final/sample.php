
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"/>
  <meta name="google-site-verification" content="Fh_dHO98PhEAYLXUNSH2UKGJ3JHFukFWVcxCQqoZ_K4"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <meta name="msapplication-tap-highlight" content="no"/>
  <meta name="csrf-token" content="PvWShNYMMQuhTLgm0UQZp9dj52+AzIj4Ce0+Q5Q+QxYN2i8I+HfGO47cffn6dmYsEI2v+RiXazKgxhT4g5whYA==" />
  <link rel="stylesheet" media="all" href="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/landing-f59771da02a964765775b913260dc3918b4656d68e1e5269e66706baeba528e8.css" />
  <link href="//fonts.googleapis.com/css?family=Open+Sans:400,600,700,400italic,300,300italic" rel="stylesheet" type="text/css">
  


<!-- For all other devices -->
<!-- Size should be 32 x 32 pixels -->
<link rel="shortcut icon" type="image/x-icon" href="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/favicon-7ccef2d9af42fbbbebde7f61fadaa6b16bf4807f320d3e3cdb5f64ec74b5f5b8.ico" />

  <script type="text/javascript">
    // To take to map page for links from old alerts email.
    if(window.location && window.location.hash && window.location.hash.indexOf &&
        window.location.hash.indexOf('#!/dashboard') !== -1 
        && window.location.hash.indexOf('fit_to_bounds') !== -1){
      window.location = '/home/' + window.location.hash;

  		
    }	
  </script>
  <script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
  <style type="text/css">
    @font-face {
      font-family: 'icomoon';
      src: url('https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/icomoon-7cfc1a0def2dcca407a1648eaac2cc3163287a757ba08da82c43684d1f283d42.eot?l3dyz');
      src: url('https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/icomoon-7cfc1a0def2dcca407a1648eaac2cc3163287a757ba08da82c43684d1f283d42.eot?l3dyz#iefix') format('embedded-opentype'),
      url('https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/icomoon-a9f4e780c022bf3d66f7cc901a56b174d4e722cebb5c92e629fab21a7005f015.ttf?l3dyz') format('truetype'),
      url('https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/icomoon-b39f7fa28c7b29b55873207abfd5a26ba653eb3b7c4e398d53fbd5d016447321.woff?l3dyz') format('woff'),
      url('https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/icomoon-7015bb21e3eecc7240dcd3776d1dbdb5d44fbe62b01c148192052ab46022a871.svg?l3dyz#icomoon') format('svg');
      font-weight: normal;
      font-style: normal;
    }

    .sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background:transparent;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
    margin-top: 35px;
	margin-left: 20px;

}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 18px;
    color: white;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: rgb(7, 181, 181);
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.nav-bar ul li ul{

	display: none;
}

.nav-bar ul li:hover > ul{
	display: block;
}
.symbol{
	position: left;
	padding-top: 30px;
	margin-left: 0px;
	color: white;
	float: left;
}
#txt1{
  color:  black;

  display: block;
}

  </style>
</head>

<body>
  <header class="banner ">
  <h1 class="logo header-logo">
    <a href="/">
      <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports">
      <span class="sr-only">CrimeReports</span>
    </a>
  </h1>

  <button id="showRight" type="button" class="collapsed visible-md visible-sm visible-xs" data-toggle="collapse" aria-expanded="false">
    <span class="sr-only">Toggle navigation</span>
    <span class="ui-menu__content">
        <i class="ui-menu__line ui-menu__line_1"></i>
        <i class="ui-menu__line ui-menu__line_2"></i>
        <i class="ui-menu__line ui-menu__line_3"></i>
      </span>
  </button>
 <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="userlogin.php">User Login</a>
  <a href="usersign.php">User Sign up</a>
  <a href="loginadmin.php">Admin Login</a>
  <a href="adminsignup.php">Admin Sign up</a>
</div>



  <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right clearfix" id="side-panel" role="navigation">
    <div class="cr-bug visible-md visible-sm visible-xs"></div>
    <div class="primary-nav">
    	<div class="nav-bar">
      <ul id="menu-primary-navigation" class="menu clearfix">
        <li id="menu-item-18" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18"><a href="new.php">Explore the Map</a></li>
       
        <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="https://www.crimereports.com/camera_registration" target="_blank">Register a Camera</a></li>

        <li id="menu-item-18" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18"><a href="pp.php">About Us</a></li>
        <li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="contus.php">Contact Us</a></li>
          
      </ul>
  </div>
    </div>
    <br>
    <br>
    <span  class="symbol" style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
    <div class="secondary-nav visible-md visible-sm visible-xs">
      <ul id="menu-secondary-navigation" class="menu">
        <li id="menu-item-23" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23"><a href="/home/#!/terms-of-use">Terms</a></li>
        <li id="menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24"><a href="/home/#!/privacy-policy">Privacy</a></li>
      </ul>
    </div>

    <div class="copyright visible-md visible-sm visible-xs">&copy; 2018 CrimeReports</div>
  </nav>
</header>

  <main class="main" role="main">
    <section class="section-padding hero">
      <div class="text">
        <div class="vertical-center">
          <div class="container">
            <div class="row">
              <div class="col-sm-12 col-md-10 col-md-offset-1">
                <h1>Welcome to CrimeReports</h1>
                <h2>Search over 1000 departments by name, region, or zip code</h2>
                <div class="searchbar">
                  <ul>
                    <li><a href="new.php" class="btn btn-success">Explore the Map</a></li>
                    <li>or</li>
                    <li>
                      <div role="search">
                        <input name="location" type="text" placeholder="Search CrimeReports" autocomplete="off" aria-label="Search CrimeReports" id="txt1" onkeyup="showHint(this.value)" />
                         <span id="txtHint" style="color: white;"><br></span></p> 
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="image" style="background-image: url('https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/home-hero-7581833e663986d3e7b7929f34691df47439e2e1932647e9be1c4e97b9b4b8d0.jpg');"></div>
    </section>

    <section class="section-padding video-section">
      <div class="container">
        <div class="row no-gutters horizontal-card">
          <div class="col-sm-6 col-md-7 col-lg-8">
            <div class="col match-height">
              <div class="thumb" style="background-image: url(https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/cr-demo-preview-map-8cd7c2ac935352dc091cfd31bba6927742be2d33aae1369cdf6121b793ee06a6.jpg)"></div>
              <button class="video-preview watch-video" data-toggle="modal" data-target="#videoModal">
                <div class="play-button">
                  <em aria-role="presentation">&#9658;</em>
                  <span class="sr-only">Watch Video</span>
                </div>
              </button>
            </div>
          </div>
          <div class="modal video-modal" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModal" aria-hidden="true">
            <div class="modal-dialog modal-lg">
              <div class="video-content modal-content">
                <div class="modal-head">
                  <span class="modal-title">How to use CrimeReports</span>
                  <button type="button" class="btn video-modal-close close pull-right" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                  <div>
                    <iframe id="howToUseCrimeReports" width="100%" height="490" src="" frameborder="0" allowfullscreen></iframe>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-5 col-lg-4">
            <div class="col match-height">
              <div class="text">
                <h3 class="margin-bottom-15">How to use CrimeReports</h3>
                <p>CrimeReports is the nation's largest collection of law enforcement agencies committed to transparency, public access, and citizen engagement.</p>
              </div>
              <div class="btn-wrapper">
                <a href="#" class="btn btn-primary btn-block watch-video"
                   data-toggle="modal" data-target="#videoModal">Watch Video</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section-padding">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <h2 class="text-center section-title">Our Services</h2>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="card match-height">
              <div class="thumb" style="background-image:url(https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/camera-c469fc34bd85bc881f6b0062c95f9dd02f0f502c52742d9561354546730da9c9.jpg);">
                <a href="https://legacy.crimereports.com/camera_registration" target="_blank"><span class="sr-only">Register a Camera</span></a>
              </div>
              <div class="text">
                <strong class="section-heading">Register a Camera</strong>
                <p>CrimeReports Camera Registration helps citizens and law enforcement partner in preventing and solving crime using your security cameras.</p>
              </div>
              <div class="btn-wrapper">
                <a href="https://legacy.crimereports.com/camera_registration" class="btn btn-primary btn-block" target="_blank">Register Camera</a>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="card match-height">
              
              <div class="text">
                <strong class="section-heading">About us</strong>
                <p>Crime reports helps to identify crime populated regions and take neccesary actions to make environment friendly.We provide you more and more opportunities to be safe and even help the authorities in identifying areas densely populated with crime.
                </p>
              </div>
              <div class="btn-wrapper">
                <a href="/subscribe" class="btn btn-primary btn-block">Subscribe</a>
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-lg-3">
            <div class="card match-height">
              <div class="thumb" style="background-image:url(https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crime-728ebc1c514f8132c045b97542a1a33156d871a919750705fdb89f4516c273e4.jpg);">
                <a href="https://www.tipsubmit.com/webtipsstart.aspx" target="_blank"><span class="sr-only">Submit a Crime Tip</span></a>
              </div>
              <div class="text">
                <strong class="section-heading">Submit a Crime Tip</strong>
                <p>Submit a crime tip to your local agency or Crime Stoppers program to help keep your community safe.</p>
              </div>
              <div class="btn-wrapper">
                <a href="contus.php" class="btn btn-primary btn-block" target="_blank">Submit Tip</a>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-3">
            <div class="card match-height">
              <div class="thumb" style="background-image:url(https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/research-391a0d1a884a978fb8e099dbb45e970e310c673b36d84dfcae3b3f015630d78f.jpg);">
                <a href="https://moto.data.socrata.com/" target="_blank"><span class="sr-only">Data Researchers</span></a>
              </div>
              <div class="text">
                <strong class="section-heading">Data Researchers</strong>
                <p>Explore some of the raw data powering CrimeReports. To access the complete API, contact us <a href=mailto:publicsafety@socrata.com>here</a>.</p>
              </div>
              <div class="btn-wrapper">
                <a href="https://moto.data.socrata.com/" class="btn btn-primary btn-block" target="_blank">View Data</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer>
    	<div class="copyright-and-privicy-links hidden-xs hidden-sm">
      <b><p style="color: blue">&copy;2018 CrimeReports</p></b>
    </footer>
  </main>  
  <script>
function showHint(str) {
  var xhttp;
  if (str.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("txtHint").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "ajax.php?q="+str, true);
  xhttp.send();   
}
</script>
</body>
</html>
