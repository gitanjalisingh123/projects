
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("Crimestopperslogo.jpg");
  min-height: 100%;
}

.bgimg-2 {
  background-image: url("aa.jpg");
  min-height: 400px;
}

.bgimg-3 {
  background-image: url("ob_cd4e4b_image-crime.jpg");
  min-height: 400px;
}

.caption {
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}
.column{
  float: left;
  width:25%;
  padding:0px; 
  padding-top: 2px;
}

.row::after{

  content: "";
  clear: both;
  display: table;
}

/* Turn off parallax scrolling for tablets and phones */
@media only screen and (max-device-width: 1024px) {
    .bgimg-1, .bgimg-2, .bgimg-3 {
        background-attachment: scroll;
    }
}
</style>

</head>
<div id="description"></div>
</div>

<script>

  loadXMLDoc();
  
  function loadXMLDoc() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        myFunction(this);
      }
    };
    xmlhttp.open("GET", "details.xml", true);
    xmlhttp.send();
  }
  function myFunction(xml) {
    console.log(xml);
    var i;
    var xmlDoc = xml.responseXML;
    console.log(xmlDoc);
    var x = xmlDoc.getElementsByTagName("member");
    console.log(x);
  final = "<div>"
     for (i = 0; i <x.length; i++) {
      
      
      
      description = "<div text-align= 'right';'> Description : " +x[i].getElementsByTagName("description")[0].childNodes[0].nodeValue+"</div>"
      "</div>"
      final = final+description;
     }
     final = final + "</div>"
     document.getElementById("description").innerHTML=final;
    
  }
  </script>

<body>

<div class="bgimg-1">
  <div class="caption">
    <span class="border">SCROLL DOWN</span>
  </div>
</div>

<div style="color: #777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
  <h3 style="text-align:center;">crime mapping</h3>
  <p>How Can I Get My Agency Online?
    Sharing crime data with the community is a choice each department makes. If you believe your agency should join this nationwide effort please contact the public information officer at your local law enforcement agency to let them know about CrimeMapping.com. Hearing from a member of the community that they serve will have a greater impact than hearing from us.</p>
</div>

<div class="bgimg-2">
  <div class="caption">
    <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">LESS HEIGHT</span>
  </div>
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
    <p>CrimeMapping.com has been developed  to help law enforcement agencies throughout panvel provide the public with valuable information about recent crime activity in their neighborhood. Our goal is to assist police departments in reducing crime through a better-informed citizenry. Creating more self-reliance among community members is a great benefit to community oriented policing efforts everywhere and has been proven effective in combating crime.</p>
  </div>
</div>

<div class="bgimg-3">
  <div class="caption">
    <span class="border" style="background-color:transparent;font-size:25px;color: #f7f7f7;">SCROLL UP</span>
  </div>
</div>

<div style="position:relative;">
  <div style="color:#ddd;background-color:#282E34;text-align:center;padding:50px 80px;text-align: justify;">
    <p>CrimeMapping.com utilizes an advanced mapping engine, which helps us provide a high level of functionality as well as flexibility to the agencies we serve. Crime data is extracted on a regular basis from each department's records system so that the information being viewed through a Web browser is the most current available. This data is always verified for accuracy and all address information is generalized by block in order to help ensure privacy is protected.</p>
  </div>
  <div id="description"></div>
</div>
<section>
  <div class="row">

    <div class="column">
      <img src="nikita.jpg" width="200px" height="300px">
      <h1>NIKITA TIKONE</h1>
      <p>Designation:Designer</p>
    </div>
    <div class="column">
      <img src="IMG-20181019-WA0001.jpg" width="200px" height="300px">
      <h1>GITANJALI SINGH</h1>
      <p>Designation:Database admin</p>
    </div>
    <div class="column">
      <img src="IMG-20181017-WA0000.jpg" width="200px" height="300px">
      <h1>SAKSHI SINGH</h1>
      <p>Designation:Developer</p>

    </div>
    <div class="column">
      <img src="IMG-20180314-WA0034.jpg" width="200px" height="300px">
      <h1>POOJA ZAGADE</h1>
      <p>Designation:Manager</p>
    </div>
  </div>
</section>
<script>

  loadXMLDoc();
  
  function loadXMLDoc() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        myFunction(this);
      }
    };
    xmlhttp.open("GET", "details.xml", true);
    xmlhttp.send();
  }
  function myFunction(xml) {
    console.log(xml);
    var i;
    var xmlDoc = xml.responseXML;
    console.log(xmlDoc);
    var x = xmlDoc.getElementsByTagName("member");
    console.log(x);
  final = "<div>"
     for (i = 0; i <x.length; i++) {
      description = "<div style='margin-top:10px;'> Description : " +x[i].getElementsByTagName("description")[0].childNodes[0].nodeValue+"</div>"
      "</div>"
      final = final+description;
     }
     final = final + "</div>"
     document.getElementById("description").innerHTML=final;
    
  }
  </script>

</body>
</html>
