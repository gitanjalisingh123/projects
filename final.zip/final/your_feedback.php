<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;
  background-image: url("one.jpg");
  background-attachment: fixed;
  background-size: cover;
  background-repeat: no-repeat;
}
form {border: 3px solid #f1f1f1;
  padding: 50px 30px 30px;
}

input[type=text], input[type=password] {
    width: 50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    background: transparent;

}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    text-decoration:none;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}



.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
.submit  {
  background-color: #55bee8;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    text-decoration:none;
    width: 25% , 25%;
    margin-left:500px;

}
.notification , .active{
  background-color: #55bee8;
    color: white;
    padding: 14px 25px;
    margin: 11px 0;
    border: none;
    cursor: pointer;
    text-decoration:none;
    width: 25% , 25%;
    margin-left:500px;

}

ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color: #111;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}

</style>
<script type="text/javascript">
  function register_submit_disable(){
var register_fname=document.getElementById('register_firstname');
var register_lname=document.getElementById('register_lastname');
var register_email=document.getElementById('register_email');


if(register_fname.value=="" || register_lname.value=="" || register_email.value ==false ){

  var register_submit=document.getElementById('register_submit');
  register_submit.disabled=true;
  register_submit.style.backgroundColor='grey';
  register_submit.style.cursor='not-allowed';
}
else{
  if(register_cpassword.value == register_password.value){
  var register_submit=document.getElementById('register_submit');
  register_submit.disabled=false;
  register_submit.style.backgroundColor='#008db1';
  register_submit.style.cursor='pointer';
}
}
}
</script>
</head>
<body>

<?php
include_once("db_connect.php");
session_start();
if(isset($_SESSION['id'])) {
  header("Location: sample.php");
}

$error = false;

if (isset($_POST['your_feedback'])) {
  
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $message = mysqli_real_escape_string($conn, $_POST['message']);
  if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
   $error = true;
    $name_error = "Name must contain only alphabets and space";
  } 
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
    $error = true;
    $email_error = "Please Enter Valid Email ID";
  }
   if (!preg_match("/^[a-zA-Z ]+$/",$message)) {
    $error = true;
    $message_error = "Name must contain only alphabets and space";
  }
  if (!$error) {
    if(mysqli_query($conn, "INSERT INTO contact(name, email, message) VALUES('" . $name . "','" . $email . "', '" . $message . "')")) {
      $success_message = " feedback Successfully sent to admin! <a href='alogged.php></a>";
    } else {
      $error_message = "Error...Please try again later!";
    }
  }
}
?>
  <div class="container">

  </div>
   <div class="logo">
      <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="300">
  <ul class="topnav">
        <LI><a href="logout.php"><strong>LOGOUT</a></LI>
       <li><a href="store.php"><strong>NOTIFICATION</a></li>
        <li><a href="map.php"><strong>EXPLORE MAP</a></li>
        <LI><a href="sample.php"><strong>HOME</a></LI>

    </ul>
  <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="your_feedback" style="height:100%; width:40%; margin-left:30%; margin-top:5%;">
    <div class="form-group">
            <label for="name">Name</label><br>
            <input type="text" id="register_fname" name="name" placeholder="Enter your name" required value="<?php if($error) echo $name; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
          </div>
    <div class="form-group">
            <label for="email">Email</label><br>
            <input type="text" name="email" id="register_email" placeholder="Enter email Name" required value="<?php if($error) echo $email; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
          </div>  
          <div class="form-group">
            <label for="message">Message</label><br>
            <input type="text" id="register_lastname" name="message" placeholder="Enter your message" required value="<?php if($error) echo $message; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($message_error)) echo $message_error; ?></span>
          </div>  
        
    <div class="form-group">
            <input type="submit" name="your_feedback" value="submit"/>
          </div>
        </fieldset>
      </form>
      <span class="text-success"><?php if (isset($success_message)) { echo $success_message; } ?></span>
      <span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
    </div>
  </div>
   <footer>
      <div class="copyright-and-privicy-links hidden-xs hidden-sm">
      <b><p style="color: blue; text-align: center;">&copy;2018 CrimeReports</p></b>
    </footer>
  </main> 
</body>
</html>