<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
     background-size: cover;
     background-image: url("abbas.jpg");


 
}
ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color:  #1295ed;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}
* {
  box-sizing: border-box;
  
    background-size: cover;
    background: transparent;
}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: block;
    border: none;
    background: transparent;
    color: black;
  
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
    background-color: grey;
    outline: none;
    color: black;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}
.btn{
  color: white;
  font-size: 20px;

}
.loginbtn{

  text-decoration: none;
  color: white;
}

/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .btn btn-primary , .loginbtn{
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
    padding: 16px;
    
    background-size: cover;
    background: transparent;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    color: white;
    padding-top: 50px;
   background-image: url("abbas.jpg");
    background-size: cover;
 
}

/* Modal Content/Box */
.modal-content {
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    color: white;
    width: 80%; /* Could be more or less, depending on screen size */
    
}
form{

    background-image: url("abbas.jpg");
    background-size: cover;
    background: transparent;
    margin: 50px 200px 200px;

}

/* Style the horizontal ruler */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
/* The Close Button (x) */
.close {
    position: absolute;
    right: 35px;
    top: 15px;
    font-size: 40px;
    font-weight: bold;
    color: #f1f1f1;
}

.close:hover,
.close:focus {
    color: #f44336;
    cursor: pointer;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}
h2{

  text-align: center;
  font-family: Arial, Helvetica, sans-serif;
  display: block;
  color: black;

}
.btn btn-primary{
  background-color: #f2c915;
}
.ucode{
   background-image: url("abbas.jpg");
  position: absolute;
  margin-left: 680px;
  background: transparent;
  color: white;
  height: 40px;


}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 600px) {
    .cancelbtn, .signupbtn, .ucode, .btm {
       width: 100%;
    }
}
.btm{

  margin-left: 710px;
  background-color: #1295ed;
}

</style>

<?php
include_once("db_connect.php");
session_start();
if(isset($_SESSION['id'])) {
	header("Location: loginadmin.php");
}

$error = false;

if (isset($_POST['adminsignup'])) {
	
  $fname = mysqli_real_escape_string($conn, $_POST['fname']);
  $mname = mysqli_real_escape_string($conn, $_POST['mname']);
  $lname = mysqli_real_escape_string($conn, $_POST['lname']);
  $address = mysqli_real_escape_string($conn, $_POST['address']);
  $contact =mysqli_real_escape_string($conn, $_POST['contact']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $pswd = mysqli_real_escape_string($conn, $_POST['pswd']);
  $cpswd = mysqli_real_escape_string($conn, $_POST['cpswd']); 
 
	
  if (!preg_match("/^[a-zA-Z ]+$/",$fname)) {
   $error = true;
    $fname_error = "Name must contain only alphabets and space";
  } 
   if (!preg_match("/^[a-zA-Z ]+$/",$mname)) {
    $error = true;
    $mname_error = "Name must contain only alphabets and space";
  }
   if (!preg_match("/^[a-zA-Z ]+$/",$lname)) {
    $error = true;
    $lname_error = "Name must contain only alphabets and space";
  }
   if (!preg_match("/^[a-zA-Z ]+$/",$address)) {
    $error = true;
    $address_error = "address must contain only alphabets and space";
  }
   if(strlen($contact) < 10) {
    $error = true;
    $contact_error = "contact must be minimum of 10 characters";
  }
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
    $error = true;
    $email_error = "Please Enter Valid Email ID";
  }
  if(strlen($pswd) < 6) {
    $error = true;
    $pswd_error = "Password must be minimum of 6 characters";
  }
  if($pswd != $cpswd) {
    $error = true;
    $cpswd_error = "Password and Confirm Password doesn't match";
  }
  $sql= "INSERT INTO uadmin(fname, mname, lname, address, contact, email, pswd, cpswd) VALUES(?,?,?,?,?,?,?,?);";
    $stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
      echo "sql error";
    }else{
      mysqli_stmt_bind_param($stmt,"ssssssss", $fname, $mname, $lname, $address, $contact, $email, $pswd, $cpswd);
      mysqli_stmt_execute($stmt);
    }
}
?>

<div id="first">
    <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="350">
<ul class="topnav">
        <li><a href="pp.php">ABOUT US</a></li>
        <li><a href="contus.php">CONTACT US</a></li>
        <LI><a href="sample.php">HOME</a></LI>
    </ul>

<div class="first"><h1 style="text-align: center; : 20px;color: white;">ADMIN SIGNUP</h1><br><br>
  <h2 style="color: white;">Enter unique code</h2><br><br><input class="ucode" id="value" type="number" name="ucode" required><br><br><br>
<button class="btm" onclick="myFunction()" style="width:auto; text-align: center;color: white;">Sign Up</button></div>
<div id="id01" class="modal">
<div class="container">
      <h1 style="text-align: center; color: white;">Sign Up</h1>
      <div class="row">
      <p style="text-align: center; color: white;">Please fill in this form to create an account.</p>

    <div class="col-md-8 col-md-offset-8 well">
      <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="adminsignup">

        <fieldset>
          <legend>Sign Up</legend>
          <div class="form-group">
            <label for="fname">First Name</label>
            <strong><input type="text" name="fname" placeholder="Enter fname Name" required value="<?php if($error) echo $fname; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($fname_error)) echo $fname_error; ?></span>
          </div> 
           <div class="form-group">
            <label for="name">Middle Name</label>
             <strong><input type="text" name="mname" placeholder="Enter mname Name" required value="<?php if($error) echo $mname; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($mname_error)) echo $mname_error; ?></span>
          </div> 
           <div class="form-group">
            <label for="name">Last Name</label>
             <strong><input type="text" name="lname" placeholder="Enter lname Name" required value="<?php if($error) echo $lname; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($lname_error)) echo $lname_error; ?></span>
          </div>  
         <div class="form-group">
            <label for="name">Address</label>
             <strong><input type="text" name="address" placeholder="Enter your address" required value="<?php if($error) echo $address; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($address_error)) echo $address_error; ?></span>
          </div>  
           <div class="form-group">
            <label for="name">Contact</label>
            <strong> <input type="text" name="contact" placeholder="Enter your phone no." required value="<?php if($error) echo $contact; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($contact_error)) echo $contact_error; ?></span>
          </div>        
          <div class="form-group">
            <label for="name">Email</label>
            <strong> <input type="text" name="email" placeholder="Email" required value="<?php if($error) echo $email; ?>" class="form-control" />
            <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
          </div>
          <div class="form-group">
            <label for="name">Password</label>
            <strong> <input type="password" name="pswd" placeholder="Password" required class="form-control" />
            <span class="text-danger"><?php if (isset($pswd_error)) echo $pswd_error; ?></span>
          </div>
          <div class="form-group">
            <label for="name">Confirm Password</label>
            <strong> <input type="password" name="cpswd" placeholder="Confirm Password" required class="form-control" />
            <span class="text-danger"><?php if (isset($cpswd_error)) echo $cpswd_error; ?></span>
          </div>
          <div class="form-group">
            <a href="process.php"><input type="submit" name="adminsignup" value="Sign Up" class="btn btn-primary" />
          </div><br>
          <div class="row">
    <div class="col-md-8 col-md-offset-8 text-center">  
      <a href="loginadmin.php" class="loginbtn">Login Here</a>
    </div>
  </div>  
        </fieldset>
      </form>
     
    </div>
  </div>
  
</div>
<script>


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  
    if (event.target == modal) {
        modal.style.display = "none"
  }
}
    
function loadDoc(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("first").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", "adminsignup.php", true);
  xhttp.send();
}

function myFunction(){
  var x=document.getElementById("value").value;
  console.log(x);
  var a='0164';
  if(x == a){
    document.getElementById('id01').style.display='block'
  }

}

</script>
</html>