<html>
<head>
<style>
		body{
				background-image: url("images1.jpg");
				background-attachment: fixed;
				background-size: cover;
				background-repeat: no-repeat;

		}
	.container{
		position:center;
		text-align:right;
	
	}

	ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color: #111;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}

</style>
</head>
<body>
	 <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="250">
<ul class="topnav">
		 <LI><a href="userlogin.php">LOGOUT</a></LI>
		 <li><a href="pp.php">ABOUT US</a></li>
        <li><a href="contus.php">CONTACT US</a></li>
        <LI><a href="sample.php">HOME</a></LI>

    </ul>

<div class="map">
<iframe src="https://www.google.com/maps/d/u/3/embed?mid=1vKc0r0-FueF4bdFTGLdhmBxS8iawP2sl" width="1520" height="680"></iframe></div>
</body>
</html>