<html>
<head>
<meta charset ="utf8">
<style type="text/css">
    body{
        background-image: url("noti.jpg");
        background-size: cover;
        background-attachment: fixed;
    }
    table{

        margin-top: 15%;
        margin-left: 35%;
        width: auto;
        font-family: Arial, Helvetica, sans-serif;
        background-color: white;
    }
    ul.topnav{

    list-style: none;
    margin: 0;
    padding: 2px;
    overflow: hidden;
    background: transparent;
}
ul.topnav li a{
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    float: right;
}
ul.topnav li a:hover:not(.active){background-color: grey;}
ul.topnav li a.active{background-color: #4CAF50;}
ul.topnav li.right {float: left;}

@media screen and (max-width: 600px){
    ul.topnav li.right,ul.topnav li{float: none;}
}

</style>
</head>
<body>
    <div class="logo">
      <img src="https://socrata-crimereports-herokuapp-com.global.ssl.fastly.net/assets/crimereports_logo-9c5607b4e61f2871de8c18ba98f93bc62abc37e0ffc5df81ffd4aeb58f2ba372.png" alt="CrimeReports" width="350">
  <ul class="topnav">
        <LI><a href="logout.php"><strong>LOGOUT</a></LI>
       <li><a href="store.php"><strong>NOTIFICATION</a></li>
        <li><a href="map.php"><strong>EXPLORE MAP</a></li>
        <LI><a href="sample.php"><strong>HOME</a></LI>

    </ul>
<table border="2" cellpadding="5px" cellspacing="3px">
    <tr>
    <th> EMAIL </th>
    <th>MESSAGE </th>
    </tr>
<?php
  $con = mysqli_connect('localhost','root','','try');
    if($con)
    {
        $query= mysqli_query($con, "call fetchProduct()");
        while($arr=mysqli_fetch_array($query))
        {
            $email= $arr[0];
            $message= $arr[1];
            echo "<tr>";
            echo "<td>$email</td>";
            echo "<td>$message</td>";
            echo "</tr>";

        }
    }
?>    
</table><br><br><br><br><br><br>
 <footer>
        <div class="copyright-and-privicy-links hidden-xs hidden-sm">
      <b><p style="color: blue; text-align: center;">&copy;2018 CrimeReports</p></b>
    </footer>
  </main> 
</body>
</html>
